import Foundation

var data = """

"""

let lines = data.split { $0.isNewline }

let lang = "ru"

for line in lines {
    let components = line.components(separatedBy: "    ")
    
    /// let word = components[0]
    let wordStr = components[0]
//    let word = String(wordStr.first!.uppercased() + String(wordStr.dropFirst()))
    let word = wordStr
    
    var categoryName = ""
    
    switch components[1] {
    case "простые":
        categoryName = lang == "en" ? "Easy" : "Простые"
    case "средние":
        categoryName = lang == "en" ? "Medium" : "Средние"
    case "сложные":
        categoryName = lang == "en" ? "Hard" : "Сложные"
    case "абстрактные":
        categoryName = lang == "en" ? "Abstract" : "Абстрактные"
    default:
        break
    }
    
    var categoryId: String = ""
    
    switch categoryName {
    case "Простые", "Easy":
        categoryId = "easy"
    case "Средние", "Medium":
        categoryId = "medium"
    case "Сложные", "Hard":
        categoryId = "hard"
    case "Абстрактные", "Abstract":
        categoryId = "abstract"
    default:
        break
    }
    
    // Swift.print("\(word) - \(type)")
    
    let item = """
    {
      "word": "\(word)",
      "categories": [
        {
          "category": {
            "name": "\(categoryName)",
            "id": "\(categoryId)"
          }
        }
      ]
    },
    """
    
    Swift.print(item)
}

/*
 
 {
   "word": "Карта мира",
   "categories": [
     {
       "category": {
         "name": "Сложные",
         "id": "hard"
       }
     }
   ]
 },
 
 */
